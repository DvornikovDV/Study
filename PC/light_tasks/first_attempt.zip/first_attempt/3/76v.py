__author__ = "Дворников Даниил. ИВТ-22"

"""Поле шахматной доски определяется парой натуральных чисел, 
каждое из которых не превосходит восьми: 
первое число — номер вертикали (при счете слева направо), 
второе — номер горизонтали (при счете снизу вверх). 
Даны натуральные числа k, l, m, n, каждое из которых не превосходит восьми. 
Требуется: На поле (k, l) расположен конь. Угрожает ли он полю (m, n)?"""

import sys
from algorithms import is_horse_threat


def main():
    if len(sys.argv) < 5:
        sys.exit("Input 4 natural values < 8. These are 2 pair's of coordinates.\nLaunch example:\npy 76v.py 1 2 3 4")

    try:
        k = int(sys.argv[1])
        l = int(sys.argv[2])
        m = int(sys.argv[3])
        n = int(sys.argv[4])
    except ValueError:
        sys.exit("One of the values is not a valid number.")

    if (k < 0 or l < 0 or m < 0 or n < 0):
        sys.exit("One of the values is not a valid number.")

    if is_horse_threat(k, l, m, n):
        print(f"Конь на поле ({k}, {l}) угрожает полю ({m}, {n}).")
    else:
        print(f"Конь на поле ({k}, {l}) не угрожает полю ({m}, {n}).")



if __name__ == "__main__":
    main()