__author__ = "Дворников Даниил. ИВТ-22"

def is_horse_threat(k: int, l: int, m: int, n: int):
    # Проверяет, угрожает ли конь на поле (k, l) полю (m, n).
    return (abs(k - m) == 2 and abs(l - n) == 1) or (abs(k - m) == 1 and abs(l - n) == 2)