__author__ = "Дворников Даниил. ИВТ-22"

import unittest
from algorithms import is_horse_threat

# Класс для тестирования
class TestKnightThreat(unittest.TestCase):
    def test_horse_threat(self):
        # Конь угрожает полю
        self.assertTrue(is_horse_threat(4, 4, 6, 3))  # Два вправо, один вниз
        self.assertTrue(is_horse_threat(4, 4, 2, 3))  # Два влево, один вниз
        self.assertTrue(is_horse_threat(4, 4, 5, 6))  # Один вправо, два вверх
        self.assertTrue(is_horse_threat(4, 4, 3, 6))  # Один влево, два вверх

    def test_horse_no_threat(self):
        # Конь не угрожает полю
        self.assertFalse(is_horse_threat(4, 4, 4, 4))  # То же самое поле
        self.assertFalse(is_horse_threat(4, 4, 5, 5))  # Диагональ (не ход коня)
        self.assertFalse(is_horse_threat(4, 4, 4, 6))  # Два вверх (не ход коня)

    def test_invalid_input(self):
        # Проверка на недопустимые входные данные
        with self.assertRaises(TypeError):
            is_horse_threat(4, 4, "a", 3)  # Некорректный тип данных

# Запуск тестов
if __name__ == "__main__":
    unittest.main()