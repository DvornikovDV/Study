__author__ = "Дворников Даниил. ИВТ-22"

"""Даны два действительных числа. 
Вывести первое число, если оно больше второго, и оба числа, если это не так."""

import sys

def main():
    if len(sys.argv) < 3:
        sys.exit("Input 2 values.\nLaunch example:\npy second.py 13.44 42")

    try:
        first_val = float(sys.argv[1])
        second_val = float(sys.argv[2])
    except ValueError:
        print("One of the values is not a number.")

    if first_val > second_val:
        print(first_val)
    else:
        print(f"{first_val}, {second_val}")


if __name__ == "__main__":
    main()