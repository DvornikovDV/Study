__author__ = "Дворников Даниил. ИВТ-22"


"""
Вычислить сумму ряда (i + 1) / (i + 2)
"""

import sys
from algorithms import product_sequense


def main():
    if len(sys.argv) < 3:
        sys.exit("Input 2 natural values - i and j (i < j). \nLaunch example:\npy 114j.py 1 2")

    try:
        i = int(sys.argv[1])
        j = int(sys.argv[2])
    except ValueError:
        sys.exit("One of the values is not a valid number.")
        

    if (i < 0 or j < 0 or i > j):
        sys.exit("One of the values is not a valid number.")

    print(f"result = {product_sequense(i, j)}")



if __name__ == "__main__":
    main()