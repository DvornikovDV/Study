__author__ = "Дворников Даниил. ИВТ-22"

def product_sequense(i: int, j: int):
    """ вычисляет произведение последовательности  (t + 1) / (t + 2)
    doc++
     """ 
    temp = 1
    for t in range(i, j + 1):
        temp = temp * ((t + 1) / (t + 2))

    return temp