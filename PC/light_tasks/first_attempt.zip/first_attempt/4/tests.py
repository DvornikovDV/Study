__author__ = "Дворников Даниил. ИВТ-22"

import unittest
from algorithms import product_sequense

class TestProductSequence(unittest.TestCase):
    def test_product_sequence_calculation(self):
        # Проверка корректности вычислений
        self.assertAlmostEqual(product_sequense(1, 2), (2/3) * (3/4))  # Пример для i=1, j=2
        self.assertAlmostEqual(product_sequense(2, 4), (3/4) * (4/5) * (5/6))  # Пример для i=2, j=4
        self.assertAlmostEqual(product_sequense(0, 1), (1/2) * (2/3))  # Пример для i=0, j=1

if __name__ == "__main__":
    unittest.main()