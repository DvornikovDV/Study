__author__ = "Дворников Даниил. ИВТ-22"

"""
Вычислить корень из произведения ряда
"""

import sys
from algorithms import *

def main():
    if len(sys.argv) < 2:
        sys.exit("Input any array of natural values. \nLaunch example:\npy 136L.py 1 2 3 4")

    arr = cli_array(sys.argv)

    print(f"result = {product_sequense(arr)}")


if __name__ == "__main__":
    main()