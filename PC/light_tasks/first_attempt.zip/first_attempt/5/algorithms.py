__author__ = "Дворников Даниил. ИВТ-22"

import math

def cli_array(argv):
    """
    Обработка ввода пользователя в cli
    Принимает список аргументов командной строки
    Возвращает список значений
    """
    try: # преобразование значений
        arr = []
        for c in argv[1:]:
            arr.append(int(c))
    except ValueError:
        sys.exit("One of the values is not a valid number.")

    for c in arr: # проверка введенных значений
        if (c < 0):
            sys.exit("One of the values is not a valid number.")

    return arr


def product_sequense(arr):
    """
    Вычисляет корень из модуля произведения последовательности
    Принимает список значений
    Возвращает результат вычислений 
    """
    temp = 1
    for t in arr:
        temp *= t

    return math.sqrt(abs(temp))