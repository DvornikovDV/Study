__author__ = "Дворников Даниил. ИВТ-22"

import unittest
from algorithms import product_sequense

class TestProductSequence(unittest.TestCase):
    def test_product_sequence_calculation(self):
        """
        Проверка корректности вычислений
        """
        self.assertAlmostEqual(product_sequense([9, 9]), 9.0, places = 6)
        self.assertAlmostEqual(product_sequense([9, 9, 13]), 32.449961, places = 6)
        self.assertAlmostEqual(product_sequense([1, 2, 3, 4, 5, 6]), 26.832816, places = 6)


if __name__ == "__main__":
    unittest.main()