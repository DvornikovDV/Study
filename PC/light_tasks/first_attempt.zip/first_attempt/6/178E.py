__author__ = "Дворников Даниил. ИВТ-22"

"""
Даны натуральные числа n, a 1...an. 
Определить количество членов ak последовательности a1,...,an:
е) имеющих четные порядковые номера и являющихся нечтными числами.
"""

import sys
from algorithms import *


def main():
    if len(sys.argv) < 2:
        sys.exit("Input any array of natural values. \nLaunch example:\npy 178E.py 1 2 3 4")

    arr = cli_array(sys.argv)

    print(f"result = {odd_count(arr)}")


if __name__ == "__main__":
    main()