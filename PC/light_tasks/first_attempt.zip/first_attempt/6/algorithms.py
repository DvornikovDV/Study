__author__ = "Дворников Даниил. ИВТ-22"

import math

def cli_array(argv):
    """
    Обработка ввода пользователя в cli
    Принимает список аргументов командной строки
    Возвращает список значений
    """
    try:
        arr = []
        for c in argv[1:]:
            arr.append(int(c))
    except ValueError:
        sys.exit("One of the values is not a valid number.")
       

    for c in arr:
        if (c < 0):
            sys.exit("One of the values is not a valid number.")

    return arr
  

def odd_count(arr):
    """
    Вычисляет кол-во нечетных чисел на четных позициях
    Принимает список значений
    Возвращает результат вычислений 
    """
    count = 0
    for t in arr[::2]:
        if t % 2 == 1:
            count += 1

    return count