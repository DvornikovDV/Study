__author__ = "Дворников Даниил. ИВТ-22"

import unittest
from algorithms import odd_count

class TestProductSequence(unittest.TestCase):
    def test_product_sequence_calculation(self):
        """
        Проверка корректности вычислений
        """
        self.assertAlmostEqual(odd_count([9, 9]), 1)
        self.assertAlmostEqual(odd_count([9, 9, 13]), 2)
        self.assertAlmostEqual(odd_count([2, 2, 2, 3, 6, 6]), 0)

if __name__ == "__main__":
    unittest.main()