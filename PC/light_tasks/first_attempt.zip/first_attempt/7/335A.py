__author__ = "Дворников Даниил. ИВТ-22"

"""
Вычислить сумму ряда [k, n] c выражением: k * (k + 1) * ... * k^2
"""

import sys
from algorithms import *

def main():
    if len(sys.argv) < 3:
        sys.exit("Input 2 natural values. \nLaunch example:\npy 335A.py 1 2")

    k, n = input_processing(sys.argv)

    print(f"result = {seq_sum_f(k, n)}")


if __name__ == "__main__":
    main()