__author__ = "Дворников Даниил. ИВТ-22"

import math

def input_processing(argv):
    """
    Обработка ввода из командного интерфейса
    """
    try:
        k = int(argv[1])
        n = int(argv[2])
    except ValueError:
        sys.exit("One of the values is not a valid number.")
        

    if (k < 0 or n < 0 or k > n):
        sys.exit("One of the values is not a valid number.")

    return k, n

def seq_sum_f(k: int, n: int):
    """
    Вычисляет сумму ряда от k до n c выражением: k * (k + 1) * ... * k^2
    Примает целые k и n
    Возвращает результат вычислений
    """
    result = 0
    for i in range(k, n + 1):
        temp = 1
        for j in range(i, i**2 + 1):
            temp *= j
        result += temp

    return result