__author__ = "Дворников Даниил. ИВТ-22"

import unittest
from algorithms import seq_sum_f

class TestProductSequence(unittest.TestCase):
    def test_product_sequence_calculation(self):
        """
        Проверка корректности вычислений
        """
        self.assertAlmostEqual(seq_sum_f(1, 2), 25)
        self.assertAlmostEqual(seq_sum_f(3, 3), 181440)
        self.assertAlmostEqual(seq_sum_f(1, 5), 646300418475611547829465)

if __name__ == "__main__":
    unittest.main()