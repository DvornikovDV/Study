__author__ = "Дворников Даниил. ИВТ-22"

"""
Дана действительная матрица [aij]i, i = 1, ..., n. 
Получить действительную матрицу [bij]i, i = 1, ..., n элемент bij
которой равен сумме элементов данной матрицы расположенных в области, 
определяемой индексами i,j так, как показано на рисунке 36 (а - г) (область заштрихована).
Область - все, что не на той йже строке или столбце.

https://ivtipm.github.io/Programming/Glava20/index20.htm#z677
"""

import sys
import numpy as np
from algorithms import *

def main():
    if len(sys.argv) != 2:
        sys.exit("Input size of matrix. \nLaunch example:\npy 677A.py 8")

    try:
        size = int(sys.argv[1])
        if (size < 1):
            sys.exit("One of the values is not a valid number.")
        mx = np.random.randint(-10, 10, size=(size, size))
    except ValueError:
        sys.exit("One of the value is not a valid number.")
    
    # Вывод исходной матрицы
    print(mx)
    # Вывод результата
    print(f"\n\nresult =\n{convert_mx(mx)}")


if __name__ == "__main__":
    main()