__author__ = "Дворников Даниил. ИВТ-22"

import math
import numpy as np

def sum_of_cross(mx, i, j):
    """
    Вычисляет сумму элементов матрицы, не включая элементы i строки и j столбца
    Принимает исходную матрицу и номера столбца и строки элемента
    Возвращает результат вычислений
    """
    """
    res = 0

    for (k, n), el in np.ndenumerate(mx):
            if k != i and n != j:
                res += el

    
    """

    return res


def convert_mx(mx):
    """
    На основе исходной матрицы mx вычисляет элементы для новой матрицы
    Возвращает преобразованную матрицу

    https://ivtipm.github.io/Programming/Glava20/index20.htm#z677
    """
    """
    result = np.zeros((mx.shape[0], mx.shape[1]))

    for (x, y) in np.ndenumerate(mx):
        result[x][y] = sum_of_cross(mx, x, y)
        
    
    for i in range(0, mx.shape[0]):
        for j in range(0, mx.shape[1]):
            
    """

    # Вычисляем сумму всех элементов матрицы
    total_sum = np.sum(mx)

    # Вычисляем суммы по строкам и столбцам
    row_sums = np.sum(mx, axis=1)
    col_sums = np.sum(mx, axis=0)

    # Создаем новую матрицу, где каждый элемент равен сумме всех элементов минус сумма строки и столбца, плюс сам элемент
    result = total_sum - row_sums[:, np.newaxis] - col_sums + mx

    return result