import unittest
import numpy as np
from algorithms import *

class TestMatrixFunctions(unittest.TestCase):
    def test_sum_of_cross(self):
        """
        Тестирование функции вычисления суммы элементов в области из условия
        """
        # Тест 1: Матрица 3x3
        matrix = np.array([[1, 2, 3],
                           [4, 5, 6],
                           [7, 8, 9]])
        self.assertEqual(sum_of_cross(matrix, 1, 1), 1 + 3 + 7 + 9)  # Исключаем строку 1 и столбец 1

        # Тест 2: Матрица 2x2
        matrix = np.array([[1, 2],
                           [3, 4]])
        self.assertEqual(sum_of_cross(matrix, 0, 0), 4)  # Исключаем строку 0 и столбец 0

        # Тест 3: Матрица с отрицательными числами
        matrix = np.array([[1, -2, 3],
                           [-4, 5, -6],
                           [7, -8, 9]])
        self.assertEqual(sum_of_cross(matrix, 2, 2), 1 - 2 - 4 + 5)  # Исключаем строку 2 и столбец 2


    def test_convert_mx(self):
        """
        Тестирование функции конвертации матрицы
        """
        # Тест 1: Матрица 2x2
        matrix = np.array([[1, 2],
                           [3, 4]])
        expected_result = np.array([[4, 3],
                                    [2, 1]])
        np.testing.assert_array_equal(convert_mx(matrix), expected_result)

        # Тест 2: Матрица 3x3
        matrix = np.array([[1, 2, 3],
                           [4, 5, 6],
                           [7, 8, 9]])
        expected_result = np.array([[5+6+8+9, 4+6+7+9, 4+5+7+8],
                                    [2+3+8+9, 1+3+7+9, 1+2+7+8],
                                    [2+3+5+6, 1+3+4+6, 1+2+4+5]])
        np.testing.assert_array_equal(convert_mx(matrix), expected_result)



if __name__ == "__main__":
    unittest.main()